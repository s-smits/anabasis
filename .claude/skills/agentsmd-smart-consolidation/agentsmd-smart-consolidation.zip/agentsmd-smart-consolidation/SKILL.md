---
name: agentsmd-smart-consolidation
description: "Consolidate AGENTS.md or other oversized instructions into a short shared core, existing skills, focused references and relevant tool-hook guidance. Use when asked to reduce tokens, restructure documentation, move sections into skills, improve skill discovery or recover missing guidance after a cut. Measure first, preserve cited rules and authority boundaries, reuse existing readers, and validate both the text and its delivery."
---

# Consolidate shared instructions

Keep the rules needed by every session in the shared file. Put detailed mechanisms in their owning
skills and supply area-specific guidance through the existing tool hook. This reduces unrelated
context without hiding the rules a session needs. The method also applies to a long `SKILL.md`,
system prompt or module manual.

Choose the structure from evidence: one to twenty new or extended skills, with zero to five helper
scripts each. Prefer extending existing components. PR #530 reported a reduction from 34,150 to
8,665 `o200k` tokens on 30 October. Four reference skills cover sections 1–14, with two or three
scripts each: `design-and-seats`, `campaign-mechanics`, `comparison-reading` and
`repository-practice`. Those counts describe that case, rather than a template to reproduce.

Token counts measure text size. Tests establish delivery under their tested conditions. Neither
establishes that models consult the right reference or make better decisions; that needs real
session evidence.

## 1. Establish the baseline

Use a dedicated worktree at the current stack head, following `stack-pr`. Preserve the starting
file with `git show <base>:AGENTS.md`, and retain snapshots at intermediate budgets. Read whole
files before editing them, including every file changed by the task.

Create a task-local token counter using the permitted runtime. Report `o200k` and `cl100k` counts,
words and characters; use `o200k` for the budgets in this protocol. The repository has no token
counter. Use `reduce-complexity`, "Reading prose as complexity", for structural measurements.

Measure five things:

| Question | Evidence |
| --- | --- |
| Which sections dominate context? | Token counts by `##` heading. In the recorded case, sections 6, 7, 11 and 1 used 5,179, 4,715, 4,468 and 4,388 tokens respectively |
| What is already documented elsewhere? | A paragraph map against existing skills. About 4,400 tokens were duplicated in the recorded case; keep one owner per fact |
| Which references are actually used? | Recent Skill invocations and available transcript evidence. Moving a fact into an unused skill may make it unavailable in practice |
| Which statements are stale? | Current symbols, callers and constants. The recorded case found ten stale claims, including `putAside`, `HOLDS` and statistical figures that depended on floors or equal margins |
| Which citations must survive? | References to section, rule, item, consequence and habit numbers, plus named headings. Preserve these anchors and check whether code or tests read the source document |

Cut by content rather than applying an equal percentage to every section. Correct stale claims
wherever they appear: shared instructions, skills and module comments.

## 2. Reuse before adding

For each passage, choose the first suitable destination:

1. Delete dead text. Consolidate duplicates under the existing owner and link to it.
2. Extend the skill that already owns the subject, using a reference file when the detail is large.
   Keep procedures with `stack-pr`, `run-management`, `attribution-and-proof`,
   `whole-run-investigation`, `simplify`, `reduce-complexity`, `commit-r`, `harness-audit` or
   `promotion-tuner` where applicable.
3. Extend an existing `tools/runtime/moments.ts` route for guidance needed at tool use. Add a route
   for a new area rather than creating another hook.
4. Add a skill only when a distinct kind of work needs it. Prefer consecutive section ranges.
   Below about 1,500 moved tokens, a new skill may not justify its always-listed description.
   Above about 6,000 tokens in one `SKILL.md`, move detail into references.

| Content | Owner |
| --- | --- |
| Shared rules, information boundaries, operator authority and evidence requirements | The core file, stated once under its existing section |
| Mechanisms, defaults, edge cases and detailed evidence rules | The owning skill's references, preserving meaning and correcting stale claims |
| Procedures | The existing procedure skill |
| Guidance needed when a tool enters an area | The existing moments hook, with a link to its owning skill |
| Status, queues and history | `docs/plan.md`, `docs/transfer.md` and commits |

## 3. Divide work where useful

Derive review lanes from the measurements. A body of text above about 3,000 tokens may justify a
cut lane; a question spanning many sites may justify a check lane. Small changes need no lanes.
The recorded case used three cut lanes and two check lanes.

Use subagents only where the operator and active instructions permit them. If freely authorised,
launch the lanes supported by the measurement. Respect any stated limit. Where permitted but
otherwise unspecified, use at most one or two check lanes and do the cutting yourself. Name lanes
left unrun. Use the configured session route, such as `codex-gpt-swarm`, and create a twin only
when requested.

Give each lane its own brief:

```text
Lane <letter>: <cut or check>, <file>, <commit>, <worktree>.
Authority: read-only on the repository; write only <scratchpad>/<letter>/.
Scope: <sections or question>, <current tokens>, <core budget>.
Destination: <owning skill and reference, or report only>.
Reuse: <existing components relevant to this lane>.
Preserve: <cited numbers, headings and authority boundaries>.
Already settled: <earlier findings that should not be repeated>.
Deliver: rewritten text or findings with file:line and revision, plus a ledger of removed
sentences and their destinations.
```

Keep your preferred conclusion out of check briefs. Verify findings against source, then write
one coherent final version rather than stitching together several voices. Update references as
you go so no required fact exists only in the old file. Move obsolete interim files to Trash.

## 4. Write the shared core

The preamble names the skills and section ranges, tells readers to consult the owning skill, and
explains that the hook never blocks. Each section states its purpose, preserves its invariants
and points to the relevant detail:

```text
**In `<skill>`, section N** (`<reference>.md`): the mechanisms explained there.
`<script> <name>` reports <the question it answers>.
```

Treat the operator's token budget as a ceiling. Reread the whole result and restore any fact whose
absence would mislead. In the recorded case, a 6,979-token draft grew by about one fifth after
review; six facts returned, including the definitions of valid answers and the reference harness.
Count again after each pass.

Use one point per paragraph and connect its sentences. Wrap prose at 100 characters while
preserving inline code, frontmatter, fences, tables, headings and quotations. Check backtick parity
and punctuation beside code spans after reflowing.

## 5. Keep skills easy to find and use

Each skill needs a focused description, a short purpose and links to relevant neighbours. Where
references are useful, map sections to files and state the question each file answers. Route
actual edits and questions using their paths and symbols, rather than repeating a contents list.

Preserve numbered headings in references. When the core owns a closed list, operator decisions or
evidence levels, link to that list rather than copying it. Preserve meaning when simplifying the
wording.

Descriptions state when to load the skill: relevant edit paths and questions, followed by scripts
and the neighbouring procedure where useful. Aim below 700 characters and stay within 1,024.
Validate the YAML, including quotes. Leave an existing description alone when its triggers are
already clear. Every new description adds text to the skill listing.

## 6. Add scripts only for unanswered questions

A script is useful when a routing question can be answered from a log or the tree and no existing
command already reports it. Use zero to five scripts per skill; a procedural skill may need none.

| Need | Reuse |
| --- | --- |
| Campaign state and evidence | `bun run runs view`, `replay`, `source`, `status`, `active`; `tools/wri/` |
| Arguments, help and remote execution | `runCommand` in `#skills/main/cli.ts`; `CommandFailure` |
| Logs by name or path | `logEvents(await logAcross(named))` |
| Imports, nearby tests and labels | `importsOf`, `nearbyTests`, `UI_SETUP` in `gate.ts`; `CATEGORIES` in `land.ts` |
| Suggested checks and affected seats | `repository-practice/scripts/preflight.ts`; `design-and-seats/scripts/seat-view.ts` |
| Size, prose and complexity | `reduce-complexity`, `bun run simplify`, `tools/loc/source-policy.ts` |
| Stack position and publication | `stack-pr/scripts/stack.ts`, `republish.ts` |
| Synthetic logs | `system-path-simulation/scripts/synthetic.ts`, or the log's typed `append` |
| Authorised parallel sessions | `codex-gpt-swarm/scripts/gpt-sessions.ts` |

Wrap production owners rather than implementing their decisions again (rule 12). Existing examples
use `startTold`, `comparisonsTold`, `failsTold`, `campaignOf`, `conditionsOf`, `settingId`,
`poolOf`, `scoredSet`, `refusals`, `planOn`, `stopRule`, `crashedRun`, `idleOf`, `sizeLines`,
`clearing` and `importsOf`. Export an existing private reader where appropriate. If a shared fact
needs a new owner, make the current caller use it too, as `supplyRun` and `spent` do. Production
must not import helpers, and every export needs an external reader.

Test scripts in `test/<skill>-script.test.ts` using valid synthetic events. A released task needs
a passed `task.gate`; a recorded condition needs `conditionId` and `requireJsonValue`. Test facts
and the nearest hostile case, including hidden-data canaries. Inspect real archived logs read-only
and report aggregate counts. Raw log-derived output remains exam-side and untracked.

Link each script from its routing row, Scripts section, core index and relevant hook route.

## 7. Use the existing moments hook

`tools/runtime/moments.ts` is registered in `.claude/settings.json` and `.codex/config.toml`.
Each `ROUTES` entry has an id, a command or path pattern, guidance text, and an owning skill or
`null`. The composer appends the instruction to read that skill; do not repeat it in each row.

Guidance appears once per area per session. The hook never refuses a call and exits successfully
when input cannot be read. Write facts and links. Add the positive route case and nearest unrelated
call to `test/moments.test.ts` when changing a route.

## 8. Validate text and delivery

Use the configured runner through plain `bun`. `RUN_REMOTE=0` requires the operator's authority.
Read every exit code:

```text
bun run format:check
bun run typecheck
bun run lint -- --strict
bun run test -- test/moments.test.ts test/skill-scripts.test.ts test/<skill>-script.test.ts ...
bun tools/loc/source-policy.ts
bun .claude/skills/repository-practice/scripts/direction.ts
git diff --check
```

Add no lint or source-policy finding. Also check token budgets, line width, em dashes, backtick
parity, punctuation, cited numbers and headings, index paths and symbols, and frontmatter names
and descriptions. Run `/simplify` on code changes before committing.

## 9. Publish without losing concurrent work

Follow `stack-pr`. Open the draft PR after its checks pass. A consolidation of shared instructions
is `importance:I1`, category `docs`, with `quality` where code moved. Keep commits independently
valid: core and references, then scripts and tests, then discovery and hook changes.

When another session pushes to the same branch, preserve your work and rebase onto its head.
Resolve each conflict by keeping its changes and applying your additions. Respect another
session's assigned wording pass. Push with a lease on the head just read; use `--no-verify` only
when authorised for that stack.

Describe the change, purpose, mechanism, measured text sizes, skill and reference counts, scripts
and their owners, stale claims corrected, code size, validation revisions and platforms, archived
observations and remaining limits. Update the description after a push. Preserve material tables,
counts and caveats.

## 10. Review known failure modes

| Failure | Correction |
| --- | --- |
| Equal percentage cuts across sections | Cut according to content |
| Inconsistent lane outputs | Write one final version after checking their findings |
| A necessary fact moved to an unused skill | Keep it in the core or make its reference discoverable |
| A duplicate skill, script or hook | Reuse the owners in sections 2 and 6 |
| Partial reading of the document | Read whole files |
| Broken code spans or frontmatter after reflow | Protect structure and validate punctuation, parity and YAML |
| An import of an unexported symbol such as `ExitWith` | Check exports and use `CommandFailure` |
| Room solves counted as comparisons | Require the matching `comparison.started` event |
| Mechanical edits over another session's wording | Preserve its work and keep only your assigned changes |
| Local checks without permission | Use plain `bun` and the configured runner |
| Real log output copied into tests | Use synthetic events; report real observations as aggregate counts |

## Report

State the change and commit. Give before-and-after token counts; skills and section ranges;
scripts and archived observations; hook routes; checks with revisions, platforms and counts; and
remaining uncertainty about model use of the references. End with the unresolved work.
