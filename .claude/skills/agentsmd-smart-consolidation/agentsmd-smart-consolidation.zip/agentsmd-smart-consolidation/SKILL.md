---
name: agentsmd-smart-consolidation
description: "Consolidate the always-loaded AGENTS.md into a short core of invariants plus as many skills as the evidence asks for (one to twenty, existing ones extended first), zero to five helper scripts each over production readers, rows of the PreToolUse moments hook and trigger-rich skill descriptions. Use when the operator asks to rewrite, shrink, consolidate, restructure or cut tokens from AGENTS.md or a large skill, to move sections into skills, to make AGENTS.md or the skills more intelligent or more triggerable, to fill gaps after such a cut, or to add a row to tools/runtime/moments.ts."
---

# AGENTS.md smart consolidation

Every Claude Code and Codex session loads `AGENTS.md` whole. A skill loads only when its
description matches the task or a pointer names it, and a hook row speaks only when a tool call
enters its area. So a fact that only the session changing one mechanism needs belongs in a skill
or a hook row, and the always-loaded file keeps what holds for every session. The same protocol
applies to any always-loaded or oversized prose: a long `SKILL.md`, a system prompt, a head comment
that became a manual.

The shape is decided by evidence, never fixed in advance: **one to twenty** new or extended skills,
and **zero to five** helper scripts in each. The default is fewer: extend what exists before adding,
reuse a component before writing one (section 2). The recorded case is PR #530 (30 October):
`AGENTS.md` went from 34,150 to 8,665 tokens (o200k). Four reference skills took its sections word
for word, under the same numbers: `design-and-seats` (sections 1 to 3), `campaign-mechanics` (4 to
6), `comparison-reading` (7 and 8) and `repository-practice` (9 to 14). They hold 2 to 3 scripts
each, and the hook gained one row per area.

The limit: token counts and tests prove what text is loaded and when. Whether models then read the
right skill at the right moment stays unobserved until real sessions show it; say so in the pull
request.

## 0. Before the first edit

- Work in a worktree of your own at the top of the stack (`stack-pr`, sections 1 to 3), never in the
  main checkout, which the follow job moves. Rebase onto a commit another session pushes; never
  rewrite it.
- Back up the starting file to the scratchpad (`git show <base>:AGENTS.md`). Keep a copy at each
  budget you reach, since a later target may want an earlier cut back.
- Read the whole file, and every file you change, whole: no `sed -n` slices (operator,
  30 October).
- Make a token counter once, in the scratchpad (a venv with `tiktoken`, printing o200k and cl100k
  counts, words and characters). Nothing in the repository counts tokens; every budget here is
  o200k. For structure, reuse `reduce-complexity`, "Reading prose as complexity".

## 1. Measure before cutting

1. **Tokens per section.** Split at the `## ` headings and count each part. A deep cut falls
   unevenly ("one 40% and the other 20%"), so cut by content, never by an equal share. On
   30 October the largest were sections 6 (5,179), 7 (4,715), 11 (4,468) and 1 (4,388).
2. **What the skills already say.** Map each paragraph against every `.claude/skills/*/SKILL.md`
   that restates it (simplify shape H6: keep a fact where it is read, point to it from the rest).
   On 30 October the skills already repeated about 4,400 tokens of `AGENTS.md`.
3. **Which skills sessions load.** Count Skill invocations in recent transcripts. A pointer to a
   skill sessions load anyway costs little; a fact moved into a skill nobody loads is lost.
4. **Dead text.** Check every claim against the source at the stack's head: the symbol, its callers,
   the constant's value. On 30 October ten claims had died (`putAside`, `HOLDS`, a p-value that
   `ROOM` changes, false rates true only at equal margins). Correct each in this change, wherever it
   stands: core, skill or head comment.
5. **What must not move.** Grep the repository, the skills, head comments and prompts for what they
   cite: `section N`, `rule N`, `item N`, numbered consequences and habits, and headings quoted by
   name. Those numbers, titles and headings stay in the core file, under the same numbers. Check
   whether any code or test reads the file (on 30 October none did).

## 2. Decide the shape: reuse first

Climb this ladder for each body of text, and stop at the first rung that holds:

1. **It is dead or duplicated.** Delete it, or keep one copy where it is read and point there.
2. **An existing skill owns its subject.** Move it into that skill's `SKILL.md` or a new
   `references/<topic>.md` beside it. The procedure skills (`stack-pr`, `run-management`,
   `attribution-and-proof`, `whole-run-investigation`, `simplify`, `reduce-complexity`, `commit-r`,
   `harness-audit`, `promotion-tuner` and the rest) are extended, never shadowed by a new skill.
3. **An existing hook row covers its area.** Add the fact to that row of `tools/runtime/moments.ts`.
   Add a row for a new area. Never add a second hook.
4. **Only then a new skill**, for a body of text that a distinct kind of work reads: a run of
   sections, a seat, a subsystem. The count follows from the work, from 1 up to 20 at most. Below
   about 1,500 tokens of moved text a new skill rarely earns its description in the always-loaded
   listing. Above about 6,000 tokens in one `SKILL.md`, split it into `references/`. Prefer one
   skill per run of consecutive sections, so a section's number finds its skill.

| Kind of text | Where it goes |
| --- | --- |
| An invariant every session must hold: a rule, a wall, what is the operator's, what a claim needs, what is never touched | The core file, once, briefly, under its section |
| How a mechanism works: table rows, defaults, edge cases, evidence rules | The owning skill's `references/<topic>.md`, word for word with corrections |
| How a procedure is carried out | The procedure skill that owns it; core and references point to it |
| A fact needed only when a tool call enters an area | A row of the moments hook, which names the owning skill |
| Status, queues, history | `docs/plan.md`, `docs/transfer.md`, commits; never the core |

## 3. Lanes, then one rewrite

1. **Derive the lanes from the measurement**, never from a fixed list. Each shape of section 2
   that moves more than about 3,000 tokens is one cut lane, and each question of section 1 with
   more than a handful of sites (duplication, dead text, citations, invocations) is one check lane.
   A small cut has no lanes. On 30 October that gave three cut lanes and two check lanes; another
   file gives another count. How many run at once follows what the operator has said of
   subagents. Where the operator's rules or words let you use them freely, launch every lane
   the measurement names, A, B, C and on to N, with no fixed ceiling. Otherwise use fewer, by
   what they have said: keep to a limit they set, and where they have said nothing, run one or
   two check lanes at most and do the cutting yourself, naming the lanes left unrun in the
   report.
   Launch them in one message, through the route the operator's rules name (`codex-gpt-swarm`
   for Codex sessions), with a twin only on the operator's word.
2. **Compose each brief from the lane's own row**, filled in, never pasted from another run:

   ```text
   Lane <letter>: <cut | check> for <file> at <commit>, in worktree <path>.
   Read-only on the repository; write only <scratchpad>/<letter>/.
   Scope: <sections or question>, now <tokens> tokens; budget <tokens> for what stays in the core.
   Destination: <skill and reference file from section 2, or "report only">.
   Reuse: <the components of section 6 this lane's text names>.
   Keep: <the cited numbers and headings of section 1, item 5, that fall in scope>.
   Already ruled out: <what earlier lanes or the measurement settled>.
   Output: the rewritten text or the findings, each with file:line at <commit>, and a ledger of
   every sentence dropped and where it now lives.
   ```

   Leave your own conclusion out of a check lane's brief. Lanes are read-only on the repository.
3. Check each lane's findings against the source. Then **rewrite the file yourself in one pass**
   from everything the lanes found. A stitched file reads as several voices with several budgets.
4. Write the full account into the skills as you go, so nothing exists only in the old file. An
   interim file is moved to the Trash once the split is done.

## 4. The core file

- **Preamble.** Name the skills with their section ranges. Say once that most tasks touch at least
  one, and that the owning skill is read before a mechanism is changed or a question about one is
  answered. Name the hook, and say it never blocks.
- **Each section.** One or two sentences on what it is about. Then its invariants in connected
  prose, so that a reader who stops there is not misled. Then one index line where a skill holds
  more:

  ```text
  **In `<skill>`, section N** (`<reference>.md`, ...): what it adds, in a few nouns.
  `<script> <name>` says what it says.
  ```

- **Budget.** Take the operator's target as a ceiling. Then reread the whole file and **put back
  every fact whose loss would mislead**, or fold it into a sentence already there. On 30 October a
  6,979-token cut grew by a fifth on the operator's word, and six facts came back, among them the
  definitions of a valid answer and the reference harness. Count after each pass.
- **Linking.** Each paragraph argues one point, with its sentences joined ("link up sentences
  better").
- **Width.** Wrap at 100 characters outside tables, fences and frontmatter. A reflow must protect
  inline code spans and the `---` frontmatter block, and must leave fences, tables, headings and
  quotes alone. Afterwards, check that no prose line holds an odd number of backticks.

## 5. The skills it moves into

A skill that gains text is one lean `SKILL.md`, with `references/` and `scripts/` only where they
earn their place (progressive disclosure):

- a frontmatter `description` built for triggering (section 7);
- a lead paragraph naming what it holds and its neighbouring skills;
- where it has references, a table from section to reference with the question each answers;
- a routing table, "If you are about to, or asking | Read or run": one row for each edit or
  question that should send a session here, with the paths and symbols it touches. Write the rows
  from what sessions do, not from the headings;
- `references/*.md` holding the moved text word for word with the corrections, under the old
  headings so a citation still finds its text. A list the core keeps (the closed list, the
  operator's decisions, the ladder) gets a pointer instead of a second copy.

## 6. Helper scripts: zero to five a skill

A script is worth writing when a routing row asks a question that a log or the tree can settle, and
no existing command already prints the answer. Give each skill as many such scripts as it has
questions like that, and no more: zero is right for a skill of pure procedure, and five is the
ceiling. Before writing one, look for what already answers it:

| Need | Existing component |
| --- | --- |
| A campaign's state, readings, moves | `bun run runs view`, `replay`, `source`, `status`, `active`; `tools/wri/` |
| Arguments, `--help`, running on another host | `runCommand` in `#skills/main/cli.ts`; throw `CommandFailure` |
| A log by name or path, on any host | `logEvents(await logAcross(named))` (`tools/runs/registry.ts`, `snapshots.ts`) |
| Imports, nearby tests, labels | `importsOf`, `nearbyTests`, `UI_SETUP` (`tools/runtime/gate.ts`), `CATEGORIES` (`land.ts`) |
| What a diff owes, which seats it reaches | `repository-practice/scripts/preflight.ts`, `design-and-seats/scripts/seat-view.ts` |
| Size, prose and complexity of a change | `reduce-complexity` (`measure.py`, `scope.sh`), `bun run simplify`, `tools/loc/source-policy.ts` |
| The stack, its top, a republish | `stack-pr/scripts/stack.ts`, `republish.ts` |
| A synthetic log for a test | `system-path-simulation/scripts/synthetic.ts`, or the log's own `append` |
| Parallel sessions | `codex-gpt-swarm/scripts/gpt-sessions.ts` |

Every script is a thin wrapper over production owners, and never derives a fact again (rule 12).
The 30 October scripts call `startTold`, `comparisonsTold` and `failsTold` over `campaignOf`;
`conditionsOf` and `settingId`; `poolOf`, `scoredSet`, `refusals` and `planOn`; `stopRule`,
`crashedRun` and `idleOf`; `sizeLines` and `clearing`; and the gate's `importsOf`. Where a script
needs what only a private function computes, export it from its owner, or add one small owner that
the existing caller shares, as `supplyRun` does with `spent` (`src/campaign/decide.ts`). Production
never imports a helper, and every export needs a reader in another file.

Test each script in `test/<skill>-script.test.ts`, on a synthetic log that the log's own types
accept. For example, `task.state` released needs a passed `task.gate` first, and
`condition.recorded` needs `conditionId` and `requireJsonValue` of its condition. Check the facts
the script prints, and include the hostile case: a canary for a held-out task or a hidden value
that must not appear. Run it read-only on real archived logs, and report what it found as counts.
Output read off a log is exam-side, so it stays out of tracked files, fixtures and pastes. Name
each script in its routing row, its Scripts section, the core's index line and its area's hook row.

## 7. Triggers: descriptions and the hook

**Descriptions.** A skill loads when its description matches, so describe what should load it:
"Read before editing <paths>" and "whenever asked <questions>", taken from its own routing table.
Then name its scripts, and end with the neighbouring skill that owns the next step. Keep it under
700 characters (1,024 is the limit), with no double quote inside the quoted YAML. Check that every
frontmatter block still parses. A skill whose "Use when" clause already names its verbs and paths
needs no change. Every new skill adds its description to every session's listing, which is one more
reason to extend before adding.

**The moments hook** (`tools/runtime/moments.ts`) is registered in `.claude/settings.json` and
`.codex/config.toml`. Each `ROUTES` row has:
- an `id`;
- a `command` or `path` pattern;
- the text it says;
- the `skill` that owns the area, or `null`.

The composer appends "Before acting, read `.claude/skills/<skill>/SKILL.md`", so no row repeats it.
It speaks once per area per session, never refuses, and exits 0 on input it cannot read. Write a
row as facts and pointers, and extend `test/moments.test.ts` with the row's positive case and its
nearest unrelated call.

## 8. Checks

Run on the runner (plain `bun`; `RUN_REMOTE=0` only on the operator's word), and read each exit
code:

```text
bun run format:check
bun run typecheck
bun run lint -- --strict            # exit 0; add no finding
bun run test -- test/moments.test.ts test/skill-scripts.test.ts test/<skill>-script.test.ts ...
bun tools/loc/source-policy.ts      # no new finding in a file the change touches
bun .claude/skills/repository-practice/scripts/direction.ts
git diff --check
```

Then check the prose: the token count against the budget, line width, no em dash, backtick parity,
every cited number and heading still found by `grep`, every path and symbol in an index line present
at the head, and every frontmatter block parsing with `name` and `description`. Run `/simplify` over
the code part of the diff before committing.

## 9. Publish

- Follow `stack-pr`. The draft pull request opens once the checks pass, without being asked. A
  consolidation that cuts what every session reads is `importance:I1`, category `docs` (with
  `quality` where code moved).
- Commits: core and references first, then scripts with their tests, then triggers and hook rows.
  Each commit passes alone.
- **Another session pushes to your branch.** Commit your work, rebase onto the new head and resolve
  conflicts hunk by hunk, with theirs as the base and your additions on top. Push with a lease on
  the head you saw. When that session is doing a wording or grammar pass, leave its wording alone
  (operator, 30 October).
- Push with `--no-verify` only on the operator's word for that stack.
- The body states the change and its mechanism, then the counts (tokens before and after; skills
  added and extended; references; scripts with their owners), the dead text corrected, net
  production lines, the checks at the pushed commit with runner and counts, what the scripts showed
  on real logs, and a "Not done" list. Rewrite it after every push that changes the pull request.

## 10. Pitfalls on record

| What went wrong | Do instead |
| --- | --- |
| An equal percentage cut from every section | Cut by content |
| The lanes' outputs stitched together | Rewrite once yourself, using what the lanes found |
| A fact moved to a skill no session loads | Keep it in the core, or point to it from the index line and the hook |
| A new skill or script beside one that already does the job | Climb the ladder of section 2 and the table of section 6 first |
| Reading slices of the file | Read whole files |
| A reflow that split a code span or flattened the frontmatter | Protect code spans and the `---` block; check parity and that the frontmatter parses |
| A script importing a symbol its module does not export (`ExitWith`) | Check the exports; throw `CommandFailure` |
| A script that called room solves a comparison | Group as a comparison only where `comparison.started` names the session |
| A mechanical pass over text another session was rewording | Leave it to that session; revert the pass and keep your additions |
| `RUN_REMOTE=0` without the operator's word | Plain `bun`, which picks a runner |
| Script output pasted into a fixture | Synthetic logs in tests; real-log output only as counts in the body |

## Report

One sentence on what changed, with the commit. Then:
- the token counts before and after;
- the skills added and extended, each with its sections;
- the scripts, with what each found on real logs;
- the hook rows;
- the checks, with their counts and runner;
- what is unobserved: whether sessions now load the right skill.

End with the "Not done" list.
